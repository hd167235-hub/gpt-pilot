#!/usr/bin/env bash
# Voxelcraft launcher (Linux / macOS) - installs the dependencies, then plays.
set -e
cd "$(dirname "$0")"
PYTHON="${PYTHON:-python3}"
echo "Installing/checking dependencies (pyglet, numpy)..."
"$PYTHON" -m pip install --quiet --disable-pip-version-check -r voxelcraft/requirements.txt \
  || "$PYTHON" -m pip install --user --quiet --disable-pip-version-check -r voxelcraft/requirements.txt
echo "Starting Voxelcraft..."
exec "$PYTHON" -m voxelcraft "$@"
