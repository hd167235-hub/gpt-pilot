@echo off
REM Voxelcraft launcher (Windows) - installs the two dependencies, then plays.
setlocal
cd /d "%~dp0"
echo Installing/checking dependencies (pyglet, numpy)...
python -m pip install --quiet --disable-pip-version-check -r voxelcraft\requirements.txt
if errorlevel 1 (
    echo.
    echo Could not install the dependencies. Is Python 3.9+ on your PATH?
    pause
    exit /b 1
)
echo Starting Voxelcraft...
python -m voxelcraft %*
if errorlevel 1 (
    echo.
    echo The game exited with an error (see the message above).
    pause
)
endlocal
